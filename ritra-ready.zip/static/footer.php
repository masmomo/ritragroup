<div class="row">

	<div class="footer text-center" style="background: #fff; font-size: 11px">
		<div class="container">
			<p class="text-center" style="line-height: 30px">&copy; 2014 PT Antikode. <a href="mailto:info@antikode.com">info@antikode.com</a>.</p>
		</div>
	</div>

</div>



