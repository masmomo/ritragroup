<div class="navbar navbar-static-top" role="navigation">
  <div class="container">

      <!--<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-data">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>-->
      <a href="<?php echo $prefix;?>home/index.php" class="navbar-brand">
        <img src="<?php echo $prefix;?>assets/img/img_logo-cargo.png" alt="logo">
      </a>

    <!--<div class="navbar-collapse collapse navbar-data" role="navigation">
      <ul class="nav navbar-nav">
        <li class="active"><a href="#">All Styles</a></li>
        <li><a href="<?php echo $prefix;?>product">Heels</a></li>
        <li><a href="<?php echo $prefix;?>product">Flats</a></li>
        <li><a href="<?php echo $prefix;?>product">Baby</a></li>
        <li><a href="<?php echo $prefix;?>product">Mens</a></li>
        <li><a href="<?php echo $prefix;?>product">Accessories</a></li>
        <li><a href="<?php echo $prefix;?>product" class="sale">Sale</a></li>
      </ul>
    </div>-->

  </div><!--.container-->
</div><!--.navbar-->
