<?php
   header( 'Location: home' ) ;
?>