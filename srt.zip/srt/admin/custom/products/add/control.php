<?php
include("custom/products/add/multiple_insert_product/control.php");

include("custom/products/add/files_control.php");
include("custom/products/add/color_control.php");
include("custom/products/add/how_control.php");
include("custom/products/add/filter_control.php");
?>