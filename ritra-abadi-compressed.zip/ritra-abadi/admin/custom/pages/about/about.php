<script>
/*
function getLanguage(file_dir){
   $('#custom_lang').html($('#custom_lang').html()+'<div id="custom_lang_select"></div>');
   
   $('#custom_lang_select').load('custom/language/pages/about/select.php');
}


function changeLanguage(lang_dir){
   var lang = $('#lang_option option:selected').val();
   location.href = '<?php echo 'http://'.$_SERVER['HTTP_HOST'].get_dirname($_SERVER['PHP_SELF']).'/';?>'+lang+'/'+lang_dir;
}   

function selectOptionLanguage(x){
   
   if(x != ''){
      $('#id_custom_select_lang option[value="'+x+'"]').attr('selected', true);
   }else{
      $('#id_custom_select_lang option[value="default"]').attr('selected', true);
   }

}

   

$(document).ready(function(e) {
   getLanguage('custom/language/select.php');
   selectOptionLanguage('<?php echo $_SESSION['lang_admin'];?>');
});
*/
</script>