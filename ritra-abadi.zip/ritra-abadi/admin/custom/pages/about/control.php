<?php
$_SESSION['lang_admin'] = "default";
?>