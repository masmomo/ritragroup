<label class="check" style="width: 130px; margin-left: 10px;">
   <input type="checkbox" name="custom_lang_default" style="margin-right:5px;"> Use default value
</label>