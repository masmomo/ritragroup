<script>
/*
$('#custom_lang').html('<li class="field-set"><div id="custom_lang_select"></div></li>'+$('#custom_lang').html());

var custom_dml = $('#category_id').val();

// LOAD SELECT
$('#custom_lang_select').load('custom/language/products/category/select.php', function() {
	//alert( "Load was performed." );
});


// LOAD CHECKBOX
$('.custom_lang_check').each(function() {
   $('.custom_lang_check').load('sources/language/check.php');
});
*/
</script>