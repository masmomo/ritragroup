

              <div class="box row">
                <div class="desc col-xs-3">
                  <h3>Files</h3>
                  <p>Manage files name.</p>
                </div>
                
                <div class="content col-xs-9">
                  <ul class="form-set">
                    <li class="form-group row">
                      <label for="brand" class="control-label col-xs-3">Files <span>*</span></label>
                      <div class="content col-xs-9">
                        <input type="file" class="form-control" name="product_files" id="id_inspiration_name">
                      </div>
                    </li>
                  </ul>
                </div>
              </div><!--box-->