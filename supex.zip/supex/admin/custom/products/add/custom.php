<?php
include('../../static/general.php');
include('../../../static/general.php');

include('filter.php');
include('files.php');
include('color.php');
include('how.php');
?>