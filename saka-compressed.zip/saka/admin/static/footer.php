<div class="footer">
    <div class="container">
        &copy; <?php echo date('Y');?> Antikode. For any enquiries, <a href="mailto:info@antikode.com">info@antikode.com</a>.
  </div>
</div>