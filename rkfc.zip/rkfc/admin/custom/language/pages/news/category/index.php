<script>
$('#custom_lang').html($('#custom_lang').html()+'<div id="custom_lang_select"></div>');

// LOAD SELECT
$('#custom_lang_select').load('../../custom/language/pages/news/category/select.php');
</script>

